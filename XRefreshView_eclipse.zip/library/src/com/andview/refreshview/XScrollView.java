package com.andview.refreshview;

import android.widget.ScrollView;

import android.content.Context;
import android.util.AttributeSet;

public class XScrollView extends ScrollView {

	private ScrollBottomListener scrollBottomListener;

	public XScrollView(Context context) {
		super(context);
	}

	public XScrollView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public XScrollView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	@Override
	protected void onScrollChanged(int l, int t, int oldl, int oldt) {
		if (t + getHeight() >= computeVerticalScrollRange()) {
			scrollBottomListener.scrollBottom();
		}
	}

	public void setOnBottomListener(
			ScrollBottomListener scrollBottomListener) {
		this.scrollBottomListener = scrollBottomListener;
	}

	public interface ScrollBottomListener {
		public void scrollBottom();
	}

}
