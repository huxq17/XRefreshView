package com.andview.refreshview;

public enum XRefreshViewState {
	STATE_READY, STATE_REFRESHING, STATE_NORMAL, STATE_LOADING, STATE_COMPLETE;
}
