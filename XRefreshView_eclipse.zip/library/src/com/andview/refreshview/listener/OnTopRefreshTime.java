package com.andview.refreshview.listener;
/**
 * 下拉刷新更多的时机
 * @author huxq17@163.com
 *
 */
public interface OnTopRefreshTime {
	public boolean isTop();
}
