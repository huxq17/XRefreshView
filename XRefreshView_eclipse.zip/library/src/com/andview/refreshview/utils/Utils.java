package com.andview.refreshview.utils;

public class Utils {

	/**
	 * 格式化字符串
	 * 
	 * @param format
	 * @param args
	 */
	public static String format(String format, int args) {
		return String.format(format, args);
	}

}
