package com.andview.example;

public class StickyListBean {
	public int section;
	public String YM;
	public String content;
	public StickyListBean(int section,String YM,String content){
		this.section = section;
		this.YM = YM;
		this.content = content;
	}
}
